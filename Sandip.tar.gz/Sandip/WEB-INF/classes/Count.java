import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class Count extends HttpServlet
{
	int cn=0;
	public void init()
	{
		ServletContext src=getServletContext();
		cn=Integer.parseInt(src.getInitParameter("fg"));
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		synchronized(this)
		{
			cn++;
		}
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		pw.print("your request:"+cn);
	}
}