import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
//class Kumsan extends HttpServlet
public class Ks extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res) throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("hello sandip");
	}
}